﻿using NssIT.Kiosk.Device.PosiFlex.StatusIndicator1.AccessSDK;
using NssIT.Kiosk.Log.DB;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PosiFlexMotionStatusIndicator01
{
    public partial class Form2 : Form
    {
        private StatusIndicator1Access _towerLight = null;

        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            string[] ports = SerialPort.GetPortNames();
            cboComPort.Items.AddRange(ports);
        }

        private StatusIndicator1Access TowerLight
        {
            get
            {
                try
                {
                    if (_towerLight == null)
                    {
                        string comPort = cboComPort.SelectedItem.ToString();

                        if (string.IsNullOrWhiteSpace(comPort) == false)
                        {
                            _towerLight = StatusIndicator1Access.GetStatusIndicator(comPort);
                        }
                        else
                        {
                            MessageBox.Show($@"No COM port selected");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }
                return _towerLight;
            }
        }

        private void ShowColorLight(StatusIndicator1Access.IndicatorColor colorArrCode)
        {
            try
            {
                if (ChkBlinking.Checked == true)
                {
                    MessageBox.Show("Done - Blinking");
                    TowerLight.ShowColor(colorArrCode, StatusIndicator1Access.LightMode.Blinking);
                }
                else
                {
                    TowerLight.ShowColor(colorArrCode);
                    MessageBox.Show("Done - Normal");
                }
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void BtnTestRedColor_Click(object sender, EventArgs e)
        {
            ShowColorLight(StatusIndicator1Access.IndicatorColor.Red);
        }

        private void BtnTestGreenColor_Click(object sender, EventArgs e)
        {
            ShowColorLight(StatusIndicator1Access.IndicatorColor.Green);
        }

        private void BtnTestBlueColor_Click(object sender, EventArgs e)
        {
            ShowColorLight(StatusIndicator1Access.IndicatorColor.Blue);
        }

        private void BtnTestAquaColor_Click(object sender, EventArgs e)
        {
            ShowColorLight(StatusIndicator1Access.IndicatorColor.Aqua);
        }

        private void BtnTestYellowColor_Click(object sender, EventArgs e)
        {
            ShowColorLight(StatusIndicator1Access.IndicatorColor.Yellow);
        }

        private void BtnTestMagentaColor_Click(object sender, EventArgs e)
        {
            ShowColorLight(StatusIndicator1Access.IndicatorColor.Magenta);
        }

        private void BtnTestWhiteColor_Click(object sender, EventArgs e)
        {
            ShowColorLight(StatusIndicator1Access.IndicatorColor.White);
        }

        private void BtnSwitchOff_Click(object sender, EventArgs e)
        {
            try
            {
                TowerLight.SwitchOff();
                MessageBox.Show("Done");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void Form2_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                _towerLight?.Dispose();
            }
            catch (Exception ex)
            { }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                DbLog log = DbLog.GetDbLog();

                log.LogText("PosiFlexMotionStatusIndicator01_Test", "*", "Test xxxxx", "ABC001", "Form2.button1_Click");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
    }
}
